var app = new Vue({
  el: "#app",
  data: {
    value: 5
  }
});
var app = new Vue({
  el: "#app",
  data: {
    timeNow: (new Date()).getTime(),
    timeBefore: 1488930695721
  }
});
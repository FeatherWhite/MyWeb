# 使用 webpack

## export 和 import

&emsp;&emsp;export 和 import 是用来导出和导入模块的。一个模块就是一个 js 文件，它拥有独立的作用域，里面定义的变量外部都无法获取。比如将一个配置文件作为模块导出，示例代码如下：

``` JavaScript
// config.js
var Config = {
    version: "1.0.0"
};
export { Config };
```

或：

```javascript
// config.js
export var config = {
	version: "1.0.0"
};
```

&emsp;&emsp;其他类型（比如函数、数组、常量等）也可以导出，比如导出一个还能输：

``` javascript
// add.js
export function add(a, b) {
    return a + b;
};
```

&emsp;&emsp;模块导出后，在需要使用模块的文件使用 import 再导入，就可以在这个文件内使用这些模块了。示例代码如下：

```javascript
// main.js
import { Config } from "./config.js";
import { add } from "./add.js";

console.log(Config);
console.log(add(1, 1));
```

&emsp;&emsp;以上几个示例中，导入的模块名称都是在 export 的文件中设置的，也就是说用户必须预先直到这个名称脚什么，比如 Config、add。而有时候，用户不想去了解名称是什么，只是要把模块的功能拿来使用，或者想自定义名称，这是可以使用 export default 来输出默认的模块。示例代码如下：

```javascript
// config.js
export default {
	version: "1.0.0"
};

// add.js
export default function (a, b) {
	return a + b;
};

// main.js
import conf from "./config.js";
import Add from "./add.js";

console.log(conf);
console.log(Add(1, 1));
```

&emsp;&emsp;如果使用 npm 安装了一些库，在 webpack 中可以直接导入，示例代码如下：

```javascript
import Vue from "vue";
import $ from "jquery";
```

&emsp;&emsp;上例分别导入了 Vue 和 jQuery 的库，并且命名为 Vue 和 $，在这个文件中就可以使用这两个模块。

## webpack 基础配置

### 安装 webpack 与 webpack-dev-server

&emsp;&emsp;首先，创建一个目录，比如 demo，使用 NPM 初始化配置：

```shell
npm init
```

&emsp;&emsp;执行后，会有一系列选项，可以按回车键快速确认，完成后 demo 目录生成一个 package.json 的文件。之后在本地局部安装 webpack：

```shell
npm install webpack --save-dev
```

&emsp;&emsp;--save-dev 会作为开发依赖来安装 webpack。安装成功后，在 package.json 中会多一项配置：

```json
"devDependencies": {
    "webpack": "^4.42.0"
}
```

&emsp;&emsp;接着需要安装 webpack-dev-server，它可以在开发环境中提供很多服务，比如启动一个服务器、热更新、接口代理等，配置起来也很简单。同样，在本地局部安装：

```shell
npm install webpack-dev-server --save-dev
```

&emsp;&emsp;在 webpack 4.0 之后需要使用 webpack-cli，所以还需要执行以下步骤：

```shell
npm install webpack-cli --save-dev
```

&emsp;&emsp;安装完成后，最终的 package.json 文件内容为：

```json
{
  "name": "webpack-basic-configuration",
  "version": "1.0.0",
  "description": "webpack 基础配置",
  "main": "index.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "xx",
  "license": "ISC",
  "devDependencies": {
    "webpack": "^4.42.0",
    "webpack-cli": "^3.3.11",
    "webpack-dev-server": "^3.10.3"
  }
}

```

&emsp;&emsp;如果 devDependencies 中包含 webpack、webpack-dev-server 和 webpack-cli，就已经安装成功，很快就可以启动 webpack 工程了。

### webpack 核心概念

&emsp;&emsp;归根到底，webpack 就是一个 .js 配置文件。首先在目录 DEMO 下创建一个 JavaScript 文件：webpack.config.js，并初始化它的内容：

```javascript
var config = {

};

module.exports = config;
```

> 这里的 module.exports = config; 相当于 export default config;。由于目前没有安装支持 ES6 的编译插件，因此不能直接使用 ES6 的语法，否则会报错。

&emsp;&emsp;然后在 package.json 的 scripts 里增加一个快速启动 webpack-dev-server 服务的脚本：

```json
{
  // ...
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "dev": "webpack-dev-server --open --config webpack.config.js"
  },
  // ...
}
```

&emsp;&emsp;当运行 npm run dev 命令时，就会执行 webpack-dev-server --open --config webpack.config.js 命令。其中 --config 是指向 webpack-dev-server 读取的配置文件路径，这里读取的是 webpack.config.js 文件。--open 会在执行命令时自动在浏览器打开页面，默认地址是 127.0.0.1：8080，不过 IP 和端口都是可以配置的。

&emsp;&emsp;webpack 配置中最重要也是必选的两项是入口（Entry）和出口（Output）。入口的作用是告诉 webpack 从哪里开始寻找依赖，并且编译，出口则用来配置编译后的文件存储位置和文件名。

&emsp;&emsp;entry 就是配置的配置的入口，webpack 会从指定的 JavaScript 文件开始工作。output 中的 path 选项用来存放打包后文件的输出目录，是必须向。publicPath 指定资源文件引用的目录，如果资源存放在 CDN 上，这里可以填 CDN 的网址。filename 用于指定输出文件的名称。

&emsp;&emsp;webpack-dev-server 的热更新功能通过建立一个 WebSocket 连接来实时响应代码的修改。使用下面的命令进行打包：

```shell
webpack --progress --hide-modules
```

这时会在设置的出口文件夹下生成一个 JavaScript 文件。

### 逐步完善配置文件

&emsp;&emsp;在 webpack 的世界里，每个文件都是一个模块，比如 .css、.js、.htlm、.jpg、.less 等等。对于不同的模块，需要用不同的加载器（Loaders）来处理，而加载器就是 webpack 最重要的功能。通过不同的加载器可以对各种不同后缀名的文件进行处理，比如现在要写一些 CSS 样式，就要用到 style-loader 和 css-loader。

&emsp;&emsp;在 module 对象的 rules 属性中可以指定一系列的 loaders，每一个 loader 都必须包含 test 和 use 两个选项。下述配置的意思为，当 webpack 编译过程中遇到 require() 或 import 语句导入一个后缀名为 .css 文件时，先将它通过 css-loader 转换，再通过 style-loader 转换，然后继续打包。use 选项的值可以是数组或字符串，如果是数组，它的编译顺序就是从后往前。

```javascript
{
	// ...
	module: {
    	rules: [
      		{
        		test: /\.css$/,
        		use: [ 'style-loader', 'css-loader' ]
      		}
    	]
  	},
  	// ...
}
```

&emsp;&emsp;webpack 的插件功能很强大而且可以定制。mini-css-extract-plugin 可以将散落在各地的 css 提取出来，并生成一个 main.css 的文件，最终在 index.html 里通过 \<link> 的形式加载它。

## Vue 单文件组件

&emsp;&emsp;Vue 单文件组件是一个后缀名为 .vue 的文件，在 webpack 中使用 vue-loader 就可以对其进行处理。一个 vue 文件一般包含了 3 个部分，即 \<template>、\<script> 和 \<style>。\<template>\</template> 之间的代码就是该组件的模板 HTML，\<style>\</style> 之间的是 CSS 样式，style 标签可以通过添加 scoped 属性，表示 CSS 只在当前组件有效，否则样式便会应用到整个项目。此外，style 还可以结合 CSS 预编译一起使用，只需设置 lang 属性即可。


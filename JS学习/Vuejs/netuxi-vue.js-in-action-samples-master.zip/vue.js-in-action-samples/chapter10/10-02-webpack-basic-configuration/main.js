import "./style.css"

document.getElementById("app").innerHTML = "Hello webpack";
import { Config } from "./config.js";
import { add } from "./add.js"

console.log(Config);
console.log(add(1, 1));
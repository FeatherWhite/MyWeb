var Config = {
  version: "1.0.0"
};

export { Config };

// export var Config = {
//   version: "1.0.0"
// }
# Render 函数

## 什么是 Virtual Dom

&emsp;&emsp;Virtual Dom 并不是真正意义上的 DOM，而是一个轻量级的 JavaScript 对象，在状态发生变化时，Vitrual Dom 会进行 Diff 运算，来更新只需要被替换的 DOM，而不是全部重绘。

&emsp;&emsp;与 DOM 操作相比，Virtual Dom 是基于 JavaScript 计算的，所以开销会小很多。

&emsp;&emsp;用 Virtual Dom 创建的 JavaScript 对象一般会是这样的：

``` JavaScript
var vNode = {
    tag: "div",
    attributes: {
        id: "main"
    },
    children: {
        // ...
    }
}
```

&emsp;&emsp;vNode 对象通过一些特定的选项描述了真实的 DOM 结构。在 Vue.js 2 中，Virtual Dom 就是通过一种 VNode 类表达的，每个 DOM 元素或组件对对应一个 VNode 对象，在 Vue.js 源码中是这样定义的：

``` JavaScript
export default class VNode {
  tag: string | void;
  data: VNodeData | void;
  children: ?Array<VNode>;
  text: string | void;
  elm: Node | void;
  ns: string | void;
  context: Component | void; // rendered in this component's scope
  key: string | number | void;
  componentOptions: VNodeComponentOptions | void;
  componentInstance: Component | void; // component instance
  parent: VNode | void; // component placeholder node

  // strictly internal
  raw: boolean; // contains raw HTML? (server only)
  isStatic: boolean; // hoisted static node
  isRootInsert: boolean; // necessary for enter transition check
  isComment: boolean; // empty comment placeholder?
  isCloned: boolean; // is a cloned node?
  isOnce: boolean; // is a v-once node?
  asyncFactory: Function | void; // async component factory function
  asyncMeta: Object | void;
  isAsyncPlaceholder: boolean;
  ssrContext: Object | void;
  fnContext: Component | void; // real context vm for functional nodes
  fnOptions: ?ComponentOptions; // for SSR caching
  devtoolsMeta: ?Object; // used to store functional render context for devtools
  fnScopeId: ?string; // functional scope id support

  constructor (
    tag?: string,
    data?: VNodeData,
    children?: ?Array<VNode>,
    text?: string,
    elm?: Node,
    context?: Component,
    componentOptions?: VNodeComponentOptions,
    asyncFactory?: Function
  ) {
    this.tag = tag
    this.data = data
    this.children = children
    this.text = text
    this.elm = elm
    this.ns = undefined
    this.context = context
    this.fnContext = undefined
    this.fnOptions = undefined
    this.fnScopeId = undefined
    this.key = data && data.key
    this.componentOptions = componentOptions
    this.componentInstance = undefined
    this.parent = undefined
    this.raw = false
    this.isStatic = false
    this.isRootInsert = true
    this.isComment = false
    this.isCloned = false
    this.isOnce = false
    this.asyncFactory = asyncFactory
    this.asyncMeta = undefined
    this.isAsyncPlaceholder = false
  }

  // DEPRECATED: alias for componentInstance for backwards compat.
  /* istanbul ignore next */
  get child (): Component | void {
    return this.componentInstance
  }
}
```

+ tag：当前节点的标签名。
+ data：当前节点的数据对象。

&emsp;&emsp;VNodeData 代码如下：

``` JavaScript
declare interface VNodeData {
  key?: string | number;
  slot?: string;
  ref?: string;
  is?: string;
  pre?: boolean;
  tag?: string;
  staticClass?: string;
  class?: any;
  staticStyle?: { [key: string]: any };
  style?: string | Array<Object> | Object;
  normalizedStyle?: Object;
  props?: { [key: string]: any };
  attrs?: { [key: string]: string };
  domProps?: { [key: string]: any };
  hook?: { [key: string]: Function };
  on?: ?{ [key: string]: Function | Array<Function> };
  nativeOn?: { [key: string]: Function | Array<Function> };
  transition?: Object;
  show?: boolean; // marker for v-show
  inlineTemplate?: {
    render: Function;
    staticRenderFns: Array<Function>;
  };
  directives?: Array<VNodeDirective>;
  keepAlive?: boolean;
  scopedSlots?: { [key: string]: Function };
  model?: {
    value: any;
    callback: Function;
  };
};
```

+ children：子节点，数组，也是 VNode 类型。
+ text：当前节点的文本，一般文本节点或注释节点会有该属性。
+ elm：当前虚拟节点对应的真实的 DOM 节点。
+ ns：节点的 namespace。
+ content：编译作用域。
+ functionalContent：函数化组件的作用域。
+ key：节点的 key 属性，用于作为节点的标识符，有利于 patch 的优化。
+ componentOptions：创建组件实例化时会用到的选项信息。
+ child：当前节点对应的组件实例。
+ parent：组件的占位节点。
+ raw：原始 html。
+ isStatic：静态节点的标识。
+ isRootInsert：是否作为根节点插入，被 \<transition> 包裹的节点，该属性的值为 false。
+ isCloned：当前节点是否为克隆节点。
+ isOnce：当前节点是否有 v-once 指令。

&emsp;&emsp;VNode 主要可以分为以下几类：

+ TextVNode：文本节点。
+ ElementVNode：普通元素节点。
+ ComponentVNode：组件节点。
+ EmptyVNode：没有内容的注释节点。
+ ClonedVNode：克隆节点，可以是以上任意类型的节点，唯一的区别在于 isCloned 属性为 true。

&emsp;&emsp;使用 Virtual Dom 就可以完全发挥 JavaScript 的编程能力。在多数场景中，我们使用 template 就足够了，但在一些特定的场景下，使用 Virtual Dom 会更简单。

## 什么是 Render 函数

&emsp;&emsp;字符串模板的代替方案，允许你发挥 JavaScript 最大的编程能力。该渲染函数接收一个 `createElement` 方法作为第一个参数用来创建 `VNode`。

&emsp;&emsp;如果组件是一个函数组件，渲染函数还会接收一个额外的 `context` 参数，为没有实例的函数组件提供上下文信息。

&emsp;&emsp;Vue 选项中的 `render` 函数若存在，则 Vue 构造函数不会从 `template` 选项或通过 `el` 选项指定的挂载元素中提取出的 HTML 模板编译渲染函数。

## createElement 用法

### 基本参数

&emsp;&emsp;createElement 构成了 Vue Virtual Dom 的模板，它有三个参数：

``` javascript
createElement (
    // { String | Object | Function }
    // 一个 HTML 标签，组件选项，或一个函数
    // 比如 Return 上述其中一个
    "div"
    // { Object }
    // 一个对应属性的数据对象，可选
    // 可以在 template 中使用
    {
    	// 稍后详细介绍
    },
    // { String | Array }
    // 子节点（VNodes），可选
    [
        createElement("h1", "Hello world"),
        createElement(MyComponent, {
            props: {
                someProp: "foo"
            }
        }),
        "bar"
    ]
}
```

&emsp;&emsp;第一个参数必选，可以是一个 HTML 标签，也可以是一个组件或函数；第二个是可选参数，数据对象，在 template 中使用。第三个是子节点，也是可选参数，用法一致。

&emsp;&emsp;对于第二个参数“数据对象”，具体的选项如下：

``` JavaScript
{
    // 和 v-bind:class 一样的 API
    "class": {
        foo: true,
        bar: false
    },
    // 和 v-bind:style 一样的 API
    style: {
        color: "red",
        fontSize: "14px"
    },
    // 正常的 HTML 特性
    attrs: {
        id: "foo"
    },
    // 组件 props
    props: {
        myProp: "bar"
    },
    // DOM 属性
    domProps: {
        innerHTML: "bar"
    },
    // 自定义事件监听器 "on"
    // 不支持 v-on:keyup.enter 的修饰器
    // 需要手动匹配 keyCode
    on: {
        click: this.clickHandler
    },
    // 自定义指令
    directives: [
        {
            name: "my-custom-directive",
            value: "2",
            expression: "1 + 1",
            arg: "foo",
            modifiers: {
                bar: true
            }
        }
    ],
    // 作用域 slot
    // { name: props => VNode | Array<VNode> }
    scopedSlots: {
        default: props => h('span', props.text)
    },
    // 如果子组件有定义 slot 的名称
    slot: "name-of-slot",
    // 其他特殊顶层属性
    key: "myKey",
    ref: "myRef"
}
```

&emsp;&emsp;在以往的 template 里，都是在组件的标签上使用形容 v-bind:class、v-bind:style、v-on:click 这样的指令，在 Render 函数里都将其写在了数据对象里。要再合适的场景使用 Render 函数，否则只会增加负担。

### 约束

&emsp;&emsp;所有的组件树中，如果 VNode 是组件或含有组件的 slot，那么 VNode 必须唯一。

### 使用 JavaScript 代替模板功能

&emsp;&emsp;在 Render 函数中，不再需要 Vue 内置的指令，比如 v-if、v-for，当然，也没办法使用。无论要实现什么功能，都可以用原生 JavaScript。

&emsp;&emsp;Render 函数里没有与 v-model 对应的 API，需要自己来实现逻辑。事实上 v-model 就是 prop: value 和 event: input 组合使用的一个语法糖，虽然在 Render 里写起来比较复杂，但是可以自由控制，深入更底层。

## 函数化组件

&emsp;&emsp;Vue.js 提供了一个 functional 的布尔值选项，设置为 true 可以使组件无状态和无实例，也就是没有 data 和 this 上下文，这样用 render 函数返回虚拟节点可以更容易渲染，因为函数化组件只是一个函数，渲染开销要小很多。

&emsp;&emsp;使用函数化组件时，Render 函数提供了第二个参数 context 来提供临时上下文，组件需要的 data、props、slots、children、parent 都是通过这个上下文来传递的，比如 this.level 要改写为 context.props.level，this.$slots.default 改写为 context.children。

&emsp;&emsp;函数化组件在业务中并不是很常用，而且也有其他类似的方法来实现，比如 is 特性实现动态挂载。总结起来函数化组件主要使用于以下两个场景：

+ 程序化地在多个组件中选择一个。
+ 在将 children, props, data 传递给子组件之前操作它们。

## JSX

&emsp;&emsp;使用 Render 函数最不友好的地方就是在模板比较简单时，写起来也很复杂，而且难以阅读出 DOM 结构，尤其当子节点嵌套较多时，嵌套的 createElement 就像盖楼 一样一层层延伸下去。

&emsp;&emsp;为了让 Render 函数更好地书写和阅读，Vue.js 提供插件 babel-plugin-transform-vue-jsx 来支持 JSX 语法，因此需要在 webpack 里配置插件 babel-plugin-transform-vue-jsx 来编译。

&emsp;&emsp;JSX 是一种看起来像 HTML，但实际是 JavaScript 的语法扩展，它用更接近 DOM 结构的形式来描述一个组件的 UI 和状态信息。JSX 仍然是 JavaScript 而不是 DOM。